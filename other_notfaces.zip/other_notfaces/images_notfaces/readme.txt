This is a subset of the non-face images from this project:

Fast Asymmetric Learning for Cascade Face Detection. 
Jianxin Wu, S. Charles Brubaker, Matthew D. Mullin, and James M. Rehg
IEEE Transactions on Pattern Analysis and Machine Intelligence, 30(3), 2008: pp. 369-382.

http://c2inet.sce.ntu.edu.sg/Jianxin/RareEvent/rare_event.htm


I left out most animal faces, illustrated faces, and duplicate images. 

I added a test set of non-face scenes used for super-resolution research, all from the SUN scene database.